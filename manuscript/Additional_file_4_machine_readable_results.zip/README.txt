Additional file 4: selected machine-readable results

This ZIP accompanies the Journal of Translational Medicine submission. It
contains the 15 CSV files listed in MANIFEST.csv. All values describe internal
TCGA analyses; performance thresholds are descriptive, not clinical or
representation-specific multiplicity-controlled discoveries.

The matched-screen, target-comparison and paired-summary files provide the
three-representation benchmark. The provenance and endpoint-dictionary files
identify direct, inferred, RNA-derived and same-H&E reference phenotypes.
The fold-stability, grouped-sensitivity and binary-operating-rule files show
how estimates changed with partitions, tissue-source-site-code grouping and
classification rule. The two COAD files are research-software outputs for
TCGA-AA-A01F and TCGA-A6-A56B; some source labels for these patients were
used in final full-data fitting, so these rows are not held-out case validation.

No fitted model objects, patient-level embeddings, WSI pixels or source
molecular matrices are included. The public analysis repository provides the
complete result inventory and code. Its licence and upstream data terms are
separate from the PathoFMPred source-code licence.
